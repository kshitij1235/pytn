elif txt_file_data[index] not in [":", "'", " ", '"']:
                