         # if characters[i] not in [",","[","]"," "]:
                        #     array_values.append(characters[i])